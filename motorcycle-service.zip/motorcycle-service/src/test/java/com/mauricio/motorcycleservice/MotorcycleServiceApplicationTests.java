package com.mauricio.motorcycleservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MotorcycleServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
